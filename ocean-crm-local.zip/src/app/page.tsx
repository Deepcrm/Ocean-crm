
import OceanCRM from "@/components/OceanCRM";

export default function Page() {
  return <OceanCRM />;
}
